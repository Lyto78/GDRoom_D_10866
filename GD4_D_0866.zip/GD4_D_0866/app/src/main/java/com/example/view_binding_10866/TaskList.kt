package com.example.view_binding_10866

object TaskList {
    val TaskList = listOf<Task>(
        Task("Chapter 1","Bangun Tidur Dengan Semangat","Dibangunkan Oleh Alarm Perang"),
        Task("Chapter 2","Share Di Internet","Share Propaganda Untuk Perang"),
        Task("Chapter 3","Buat Senjata Nuklir","Buat senjata Nuklir untuk perang"),
        Task("Chapter 4","Nonton Perang","Nonton perang sambil bersantai")
    )
}